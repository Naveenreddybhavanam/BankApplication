# bankingtransaction
connecting  mysql database using jdbc and displaying transactions
